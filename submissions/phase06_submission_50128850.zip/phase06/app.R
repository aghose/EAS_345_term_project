library(shiny)

#Run This BEFORE running the app
source("phase06.R")

shinyApp(ui, server)
